import os
import cv2
import numpy as np
from sklearn.decomposition import PCA
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

def load_images_from_folder(folder):
    images = []
    labels = []
    label_names = []

    for label, person_name in enumerate(os.listdir(folder)):
        person_folder = os.path.join(folder, person_name)
        if not os.path.isdir(person_folder):
            continue

        for filename in os.listdir(person_folder):
            img_path = os.path.join(person_folder, filename)
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            if img is not None:
                img_resized = cv2.resize(img, (100, 100))
                images.append(img_resized.flatten())
                labels.append(label)
                if label not in label_names:
                    label_names.append(person_name)

    images = np.array(images)
    labels = np.array(labels)
    if len(images) == 0 or len(labels) == 0:
        raise ValueError("No images or labels found. Check your dataset.")
    
    return images, labels, label_names

def perform_pca(images, n_components):
    mean_face = np.mean(images, axis=0)
    zero_mean_faces = images - mean_face

    pca = PCA(n_components=n_components, svd_solver='randomized', whiten=True).fit(zero_mean_faces)
    eigenfaces = pca.components_.reshape((n_components, -1))

    return mean_face, eigenfaces, pca

def train_ann(signatures, labels):
    X_train, X_test, y_train, y_test = train_test_split(signatures, labels, test_size=0.4, random_state=42)
    ann_model = MLPClassifier(hidden_layer_sizes=(100,), max_iter=1000, early_stopping=True, validation_fraction=0.1, n_iter_no_change=10, random_state=42)
    ann_model.fit(X_train, y_train)

    accuracy = accuracy_score(y_test, ann_model.predict(X_test))
    print(f'ANN Training Accuracy: {accuracy * 100:.2f}%')

    return ann_model, X_test, y_test

def recognize_face(test_image, mean_face, pca_model, ann_model):
    zero_mean_test_image = test_image.flatten() - mean_face
    test_signature = pca_model.transform([zero_mean_test_image])
    predicted_label = ann_model.predict(test_signature)
    return predicted_label

def plot_accuracy_vs_k(images, labels):
    k_values = range(10, 101, 10)
    accuracies = []

    for k in k_values:
        mean_face, eigenfaces, pca_model = perform_pca(images, n_components=k)
        signatures = pca_model.transform(images)
        X_train, X_test, y_train, y_test = train_test_split(signatures, labels, test_size=0.4, random_state=42)

        ann_model = MLPClassifier(hidden_layer_sizes=(100,), max_iter=1000, early_stopping=True, validation_fraction=0.1, n_iter_no_change=10, random_state=42)
        ann_model.fit(X_train, y_train)
        y_pred = ann_model.predict(X_test)

        accuracy = accuracy_score(y_test, y_pred)
        accuracies.append(accuracy)

    plt.plot(k_values, accuracies)
    plt.xlabel('k (Number of Eigenfaces)')
    plt.ylabel('Accuracy')
    plt.title('Accuracy vs Number of Eigenfaces')
    plt.show()
