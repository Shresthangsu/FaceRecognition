from utils import load_images_from_folder, perform_pca, train_ann, recognize_face, plot_accuracy_vs_k
import cv2
import numpy as np

# Load the dataset
images, labels, label_names = load_images_from_folder('dataset/faces')

if len(images) == 0 or len(labels) == 0:
    raise ValueError("No images or labels found in the dataset.")

# Experiment with PCA components
n_components = 50  # Start with 50, adjust based on accuracy plot
mean_face, eigenfaces, pca_model = perform_pca(images, n_components=n_components)

if eigenfaces.shape[0] < n_components:
    raise ValueError(f"Number of components ({n_components}) exceeds the available eigenfaces ({eigenfaces.shape[0]}).")

# Transform images into signatures
signatures = pca_model.transform(images)

# Train the ANN model
ann_model, X_test, y_test = train_ann(signatures, labels)

# Test with a new image
test_img_path = 'test.jpg'
test_img = cv2.imread(test_img_path, cv2.IMREAD_GRAYSCALE)

if test_img is None:
    print(f"Error: Unable to load image '{test_img_path}'.")
else:
    test_img_resized = cv2.resize(test_img, (100, 100))
    test_img_normalized = test_img_resized.flatten() - np.mean(images, axis=0)  # Ensure normalization
    test_signature = pca_model.transform([test_img_normalized])
    
    predicted_label = recognize_face(test_img_resized, mean_face, pca_model, ann_model)
    print(f'The predicted label is: {label_names[predicted_label[0]]}')

# Optional: Plot accuracy vs. number of eigenfaces
plot_accuracy_vs_k(images, labels)
